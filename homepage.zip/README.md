# Arneb_webpage
Webpack \
npm i -D parcel-bundler \
npm run dev
